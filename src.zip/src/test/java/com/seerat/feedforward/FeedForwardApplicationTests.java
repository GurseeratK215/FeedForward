package com.seerat.feedforward;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedForwardApplicationTests {

    System.out.print("Hello");

}
