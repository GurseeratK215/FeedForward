// NOT REQUIRED



// package com.seerat.feedforward.dto;

// import java.util.List;

// public class Dto {
//     private List<Restaurant> data;

//     // Getters and setters
//     @Getter
//     @Setter
//     public static class Restaurant {
//         private String restaurant_name;
//         private String address;

//         // Getters and setters
//     }
// }
