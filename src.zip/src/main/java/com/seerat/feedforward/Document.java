package com.seerat.feedforward;

public @interface Document {
    String collection();
}
