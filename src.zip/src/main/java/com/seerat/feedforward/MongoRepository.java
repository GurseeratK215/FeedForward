// REMOVE

// package com.seerat.feedforward;

// public interface MongoRepository<V, I extends Number> {
// }
